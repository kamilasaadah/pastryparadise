import '../models/recipe.dart';
import '../models/review.dart';
import '../data/dummy_data.dart';
import '../data/dummy_reviews.dart';

class RecipeService {
  Future<List<Recipe>> getAllRecipes() async {
    return dummyRecipes;
  }

  Future<List<Recipe>> getRecipesByCategory(String category) async {
    if (category == 'All') {
      return dummyRecipes;
    }
    return dummyRecipes.where((recipe) => 
      recipe.category.toLowerCase() == category.toLowerCase()
    ).toList();
  }

  Future<List<Recipe>> getPopularRecipes() async {
    return dummyRecipes.take(5).toList();
  }

  Future<List<Recipe>> getNewestRecipes() async {
    // Explicitly cast to List<Recipe> to fix type error
    return List<Recipe>.from(dummyRecipes.reversed).take(5).toList();
  }

  Future<List<Recipe>> getFavoriteRecipes() async {
    return dummyRecipes.where((recipe) => recipe.isFavorite).toList();
  }

  Future<List<Recipe>> searchRecipes(String query) async {
    if (query.isEmpty) {
      return dummyRecipes;
    }
    return dummyRecipes.where((recipe) => 
      recipe.title.toLowerCase().contains(query.toLowerCase()) ||
      recipe.description.toLowerCase().contains(query.toLowerCase())
    ).toList();
  }

  Future<void> toggleFavorite(int recipeId) async {
    final recipeIndex = dummyRecipes.indexWhere((recipe) => recipe.id == recipeId);
    if (recipeIndex != -1) {
      dummyRecipes[recipeIndex].isFavorite = !dummyRecipes[recipeIndex].isFavorite;
    }
  }
  
  Future<List<Review>> getReviewsForRecipe(int recipeId) async {
    // In a real app, this would filter reviews by recipe ID
    // For demo purposes, return all dummy reviews
    return dummyReviews;
  }
}

