import '../models/recipe.dart';
import '../data/dummy_data.dart';

// Mock database helper for frontend-only implementation
class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  
  // In-memory storage
  Map<String, String>? _currentUser;
  
  DatabaseHelper._init();
  
  // User Authentication Methods
  Future<bool> registerUser(String name, String email, String password) async {
    try {
      // Check if email already exists
      if (_currentUser != null && _currentUser!['email'] == email) {
        return false; // Email already exists
      }
      
      // Store user in memory
      _currentUser = {
        'name': name,
        'email': email,
        'password': password,
        'profile_image': 'https://randomuser.me/api/portraits/men/32.jpg',
      };
      
      return true;
    } catch (e) {
      // Use debugPrint or a logger in a real app
      return false;
    }
  }

  Future<Map<String, dynamic>?> loginUser(String email, String password) async {
    try {
      // Simple in-memory check
      if (_currentUser != null && 
          _currentUser!['email'] == email && 
          _currentUser!['password'] == password) {
        return _currentUser!;
      }
      
      // For demo purposes, allow login with any credentials
      if (_currentUser == null) {
        _currentUser = {
          'name': 'John Doe',
          'email': email,
          'password': password,
          'profile_image': 'https://randomuser.me/api/portraits/men/32.jpg',
        };
        return _currentUser!;
      }
      
      return null; // Invalid credentials
    } catch (e) {
      // Use debugPrint or a logger in a real app
      return null;
    }
  }

  Future<void> logoutUser() async {
    _currentUser = null;
  }

  Future<Map<String, dynamic>?> getCurrentUser() async {
    return _currentUser;
  }

  // Recipe Methods
  Future<List<Recipe>> getRecipes() async {
    return dummyRecipes;
  }

  Future<List<Recipe>> getRecipesByCategory(String category) async {
    return dummyRecipes.where((recipe) => 
      recipe.category.toLowerCase() == category.toLowerCase()
    ).toList();
  }

  Future<List<Recipe>> getPopularRecipes() async {
    return dummyRecipes.take(5).toList();
  }

  Future<List<Recipe>> getNewestRecipes() async {
    // Explicitly cast to List<Recipe> to fix type error
    return List<Recipe>.from(dummyRecipes.reversed).take(5).toList();
  }

  Future<List<Recipe>> getFavoriteRecipes() async {
    return dummyRecipes.where((recipe) => recipe.isFavorite).toList();
  }

  Future<List<Recipe>> searchRecipes(String query) async {
    return dummyRecipes.where((recipe) => 
      recipe.title.toLowerCase().contains(query.toLowerCase()) ||
      recipe.description.toLowerCase().contains(query.toLowerCase())
    ).toList();
  }

  Future<void> toggleFavorite(int recipeId) async {
    final recipeIndex = dummyRecipes.indexWhere((recipe) => recipe.id == recipeId);
    if (recipeIndex != -1) {
      dummyRecipes[recipeIndex].isFavorite = !dummyRecipes[recipeIndex].isFavorite;
    }
  }
}

