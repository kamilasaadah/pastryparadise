// lib/screens/home_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import '../models/recipe.dart';
import '../services/database_helper.dart';
import '../utils/platform_helper.dart';
import '../widgets/adaptive_widgets.dart';
import '../theme/app_theme.dart';
import 'recipe_detail_screen.dart';
import 'profile_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => HomeScreenState();
}

class HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  List<Recipe> _recipes = [];
  List<Recipe> _filteredRecipes = [];
  bool _isLoading = true;
  String _searchQuery = '';
  late TabController _tabController;
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _tabController.addListener(() {
      setState(() {});
    });
    _loadRecipes();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadRecipes() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final recipes = await DatabaseHelper.instance.getRecipes();
      if (!mounted) return;

      setState(() {
        _recipes = recipes;
        _filteredRecipes = recipes;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error loading recipes: $e')),
      );
    }
  }

  void _filterRecipes(String query) {
    setState(() {
      _searchQuery = query;
      if (query.isEmpty) {
        _filteredRecipes = _recipes;
      } else {
        _filteredRecipes = _recipes
            .where((recipe) =>
                recipe.title.toLowerCase().contains(query.toLowerCase()))
            .toList();
      }
    });
  }

  Future<List<Recipe>> _getTabRecipes() async {
    switch (_tabController.index) {
      case 0:
        return await DatabaseHelper.instance.getPopularRecipes();
      case 1:
        return await DatabaseHelper.instance.getNewestRecipes();
      case 2:
        return await DatabaseHelper.instance.getFavoriteRecipes();
      default:
        return _filteredRecipes;
    }
  }

  Widget _buildHomeContent() {
    return _isLoading
        ? const Center(child: AdaptiveProgressIndicator())
        : SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Search Bar
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: PlatformHelper.shouldUseMaterial
                      ? TextField(
                          decoration: InputDecoration(
                            hintText: 'Cari resep pastry...',
                            hintStyle: const TextStyle(
                              fontFamily: 'Roboto',
                            ),
                            prefixIcon: const Icon(Icons.search),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(25.0),
                            ),
                            contentPadding: const EdgeInsets.symmetric(vertical: 0),
                          ),
                          onChanged: _filterRecipes,
                        )
                      : CupertinoSearchTextField(
                          placeholder: 'Cari resep pastry...',
                          style: const TextStyle(
                            fontFamily: 'Roboto',
                          ),
                          onChanged: _filterRecipes,
                        ),
                ),

                // Kategori horizontal
                SizedBox(
                  height: 40,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    children: [
                      _buildCategoryChip('Semua', isSelected: true),
                      _buildCategoryChip('Croissant'),
                      _buildCategoryChip('Éclair'),
                      _buildCategoryChip('Macaron'),
                      _buildCategoryChip('Tart'),
                      _buildCategoryChip('Puff Pastry'),
                    ],
                  ),
                ),

                // Tab Bar untuk filter Populer/Terbaru/Favorit
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: PlatformHelper.shouldUseMaterial
                      ? TabBar(
                          controller: _tabController,
                          labelColor: Theme.of(context).primaryColor,
                          unselectedLabelColor: Colors.grey,
                          indicatorColor: Theme.of(context).primaryColor,
                          tabs: const [
                            Tab(
                              child: Text(
                                'Populer',
                                style: TextStyle(
                                  fontFamily: 'Roboto',
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500,
                                  decoration: TextDecoration.none, // Hilangkan underline
                                ),
                              ),
                            ),
                            Tab(
                              child: Text(
                                'Terbaru',
                                style: TextStyle(
                                  fontFamily: 'Roboto',
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500,
                                  decoration: TextDecoration.none, // Hilangkan underline
                                ),
                              ),
                            ),
                            Tab(
                              child: Text(
                                'Favorit',
                                style: TextStyle(
                                  fontFamily: 'Roboto',
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500,
                                  decoration: TextDecoration.none, // Hilangkan underline
                                ),
                              ),
                            ),
                          ],
                        )
                      : CupertinoSegmentedControl<int>(
                          children: {
                            0: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 16),
                              child: Text(
                                'Populer',
                                style: TextStyle(
                                  fontFamily: 'Roboto',
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500,
                                  decoration: TextDecoration.none, // Hilangkan underline
                                  color: _tabController.index == 0
                                      ? CupertinoColors.white
                                      : CupertinoColors.black,
                                ),
                              ),
                            ),
                            1: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 16),
                              child: Text(
                                'Terbaru',
                                style: TextStyle(
                                  fontFamily: 'Roboto',
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500,
                                  decoration: TextDecoration.none, // Hilangkan underline
                                  color: _tabController.index == 1
                                      ? CupertinoColors.white
                                      : CupertinoColors.black,
                                ),
                              ),
                            ),
                            2: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 16),
                              child: Text(
                                'Favorit',
                                style: TextStyle(
                                  fontFamily: 'Roboto',
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500,
                                  decoration: TextDecoration.none, // Hilangkan underline
                                  color: _tabController.index == 2
                                      ? CupertinoColors.white
                                      : CupertinoColors.black,
                                ),
                              ),
                            ),
                          },
                          onValueChanged: (index) {
                            setState(() {
                              _tabController.animateTo(index);
                            });
                          },
                          groupValue: _tabController.index,
                          borderColor: Theme.of(context).primaryColor,
                          selectedColor: Theme.of(context).primaryColor,
                          unselectedColor: CupertinoColors.systemGrey5,
                        ),
                ),

                // Daftar Resep berdasarkan tab
                SizedBox(
                  height: 320,
                  child: _filteredRecipes.isEmpty
                      ? Center(
                          child: Text(
                            _searchQuery.isEmpty
                                ? 'Tidak ada resep'
                                : 'Tidak ada resep yang cocok',
                            style: const TextStyle(fontFamily: 'Roboto'),
                          ),
                        )
                      : FutureBuilder<List<Recipe>>(
                          future: _getTabRecipes(),
                          builder: (context, snapshot) {
                            if (snapshot.connectionState == ConnectionState.waiting) {
                              return const Center(child: AdaptiveProgressIndicator());
                            }

                            if (snapshot.hasError) {
                              return Center(child: Text('Error: ${snapshot.error}'));
                            }

                            final recipes = snapshot.data ?? [];

                            if (recipes.isEmpty) {
                              return const Center(child: Text('Tidak ada resep'));
                            }

                            return ListView.builder(
                              padding: const EdgeInsets.symmetric(horizontal: 16.0),
                              scrollDirection: Axis.horizontal,
                              itemCount: recipes.length,
                              itemBuilder: (context, index) {
                                final recipe = recipes[index];
                                return SizedBox(
                                  width: 250,
                                  child: Card(
                                    margin: const EdgeInsets.only(right: 12.0, bottom: 12.0),
                                    clipBehavior: Clip.antiAlias,
                                    elevation: 2,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: InkWell(
                                      onTap: () {
                                        Navigator.push(
                                          context,
                                          adaptivePageRoute(
                                            builder: (context) => RecipeDetailScreen(recipe: recipe),
                                          ),
                                        );
                                      },
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Stack(
                                            children: [
                                              Image.network(
                                                recipe.imageUrl,
                                                height: 150,
                                                width: double.infinity,
                                                fit: BoxFit.cover,
                                                errorBuilder: (context, error, stackTrace) {
                                                  return Container(
                                                    height: 150,
                                                    color: Colors.grey[300],
                                                    child: const Center(
                                                      child: Icon(Icons.image_not_supported, size: 50),
                                                    ),
                                                  );
                                                },
                                              ),
                                              Positioned(
                                                top: 10,
                                                right: 10,
                                                child: Container(
                                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                                  decoration: BoxDecoration(
                                                    color: Colors.black.withAlpha(153),
                                                    borderRadius: BorderRadius.circular(20),
                                                  ),
                                                  child: Text(
                                                    recipe.difficulty,
                                                    style: const TextStyle(
                                                      color: Colors.white,
                                                      fontSize: 12,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.all(12.0),
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  recipe.title,
                                                  style: const TextStyle(
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.bold,
                                                    fontFamily: 'Roboto',
                                                  ),
                                                  maxLines: 1,
                                                  overflow: TextOverflow.ellipsis,
                                                ),
                                                const SizedBox(height: 4),
                                                Text(
                                                  recipe.description,
                                                  maxLines: 2,
                                                  overflow: TextOverflow.ellipsis,
                                                  style: TextStyle(
                                                    color: Theme.of(context).brightness == Brightness.dark
                                                        ? AppTheme.darkMutedTextColor
                                                        : Colors.grey[600],
                                                    fontSize: 12,
                                                  ),
                                                ),
                                                const SizedBox(height: 8),
                                                Row(
                                                  children: [
                                                    Icon(
                                                      PlatformHelper.shouldUseMaterial
                                                          ? Icons.timer
                                                          : CupertinoIcons.time,
                                                      size: 14,
                                                      color: Theme.of(context).brightness == Brightness.dark
                                                          ? AppTheme.darkMutedTextColor
                                                          : Colors.grey[600],
                                                    ),
                                                    const SizedBox(width: 4),
                                                    Text(
                                                      '${recipe.prepTime + recipe.cookTime} menit',
                                                      style: TextStyle(
                                                        color: Theme.of(context).brightness == Brightness.dark
                                                            ? AppTheme.darkMutedTextColor
                                                            : Colors.grey[600],
                                                        fontSize: 12,
                                                      ),
                                                    ),
                                                    const Spacer(),
                                                    Icon(
                                                      recipe.isFavorite 
                                                          ? (PlatformHelper.shouldUseMaterial
                                                              ? Icons.favorite
                                                              : CupertinoIcons.heart_fill)
                                                          : (PlatformHelper.shouldUseMaterial
                                                              ? Icons.favorite_border
                                                              : CupertinoIcons.heart),
                                                      size: 14, 
                                                      color: recipe.isFavorite 
                                                          ? Theme.of(context).primaryColor 
                                                          : (Theme.of(context).brightness == Brightness.dark
                                                              ? AppTheme.darkMutedTextColor
                                                              : Colors.grey[600]),
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                ),

                // Kategori Pastry
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'Kategori Pastry',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              decoration: TextDecoration.none,
                            ),
                          ),
                          TextButton(
                            onPressed: () {},
                            child: const Text(
                            'Lihat Semua',
                            style: TextStyle(
                              decoration: TextDecoration.none, // Hilangkan underline
                            ),
                          ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      SizedBox(
                        height: 120,
                        child: ListView(
                          scrollDirection: Axis.horizontal,
                          children: [
                            _buildCategoryItem('Croissant', 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?q=80&w=1000', 24),
                            _buildCategoryItem('Éclair', 'https://images.unsplash.com/photo-1626803775151-61d756612f97?q=80&w=1000', 18),
                            _buildCategoryItem('Macaron', 'https://images.unsplash.com/photo-1569864358642-9d1684040f43?q=80&w=1000', 32),
                            _buildCategoryItem('Tart', 'https://images.unsplash.com/photo-1464305795204-6f5bbfc7fb81?q=80&w=1000', 27),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                // Tips & Trik
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'Tips & Trik',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              decoration: TextDecoration.none,
                            ),
                          ),
                          TextButton(
                            onPressed: () {},
                            child: const Text('Lihat Semua'),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      _buildTipItem(
                        'Tips Membuat Adonan Puff Pastry yang Sempurna',
                        'Pelajari teknik melipat dan mendinginkan adonan untuk hasil yang berlapis-lapis.',
                        'https://images.unsplash.com/photo-1509440159596-0249088772ff?q=80&w=1000',
                      ),
                      const SizedBox(height: 12),
                      _buildTipItem(
                        'Teknik Dekorasi Kue Tart untuk Pemula',
                        'Cara mudah menghias kue tart dengan hasil yang profesional.',
                        'https://images.unsplash.com/photo-1464305795204-6f5bbfc7fb81?q=80&w=1000',
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
  }

  Widget _buildFavoritesContent() {
    return FutureBuilder<List<Recipe>>(
      future: DatabaseHelper.instance.getFavoriteRecipes(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: AdaptiveProgressIndicator());
        }
        
        if (snapshot.hasError) {
          return Center(
            child: Text('Error: ${snapshot.error}'),
          );
        }
        
        final favorites = snapshot.data ?? [];
        
        if (favorites.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  PlatformHelper.shouldUseMaterial
                      ? Icons.favorite
                      : CupertinoIcons.heart,
                  size: 80,
                  color: Theme.of(context).primaryColor.withAlpha(77),
                ),
                const SizedBox(height: 16),
                const Text(
                  'Belum ada resep favorit',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Tambahkan resep ke favorit dengan menekan ikon hati',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.grey,
                  ),
                ),
              ],
            ),
          );
        }
        
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: favorites.length,
          itemBuilder: (context, index) {
            final recipe = favorites[index];
            return Card(
              margin: const EdgeInsets.only(bottom: 16),
              child: ListTile(
                contentPadding: const EdgeInsets.all(12),
                leading: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.network(
                    recipe.imageUrl,
                    width: 60,
                    height: 60,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return Container(
                        width: 60,
                        height: 60,
                        color: Colors.grey[300],
                        child: const Icon(Icons.image_not_supported),
                      );
                    },
                  ),
                ),
                title: Text(
                  recipe.title,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Text(
                  recipe.description,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                trailing: IconButton(
                  icon: Icon(
                    PlatformHelper.shouldUseMaterial
                        ? Icons.favorite
                        : CupertinoIcons.heart_fill,
                    color: Colors.red,
                  ),
                  onPressed: () async {
                    await DatabaseHelper.instance.toggleFavorite(recipe.id);
                    if (mounted) {
                      setState(() {});
                    }
                  },
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    adaptivePageRoute(
                      builder: (context) => RecipeDetailScreen(recipe: recipe),
                    ),
                  );
                },
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return AdaptiveScaffold(
      appBar: _currentIndex == 2 
          ? null
          : AdaptiveAppBar(
              title: 'Pastry Paradise',
              actions: [
                IconButton(
                  icon: Icon(
                    PlatformHelper.shouldUseMaterial
                        ? Icons.notifications_outlined
                        : CupertinoIcons.bell,
                  ),
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Fitur notifikasi akan segera hadir!'),
                        duration: Duration(seconds: 1),
                      ),
                    );
                  },
                ),
              ],
            ),
      body: IndexedStack(
        index: _currentIndex,
        children: [
          _buildHomeContent(),
          _buildFavoritesContent(),
          const ProfileScreen(),
        ],
      ),
      bottomNavigationBar: AdaptiveBottomNavigation(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: const [
          BottomNavigationItem(
            label: 'Beranda',
            materialIcon: Icons.home,
            cupertinoIcon: CupertinoIcons.home,
          ),
          BottomNavigationItem(
            label: 'Favorit',
            materialIcon: Icons.favorite,
            cupertinoIcon: CupertinoIcons.heart,
          ),
          BottomNavigationItem(
            label: 'Profil',
            materialIcon: Icons.person,
            cupertinoIcon: CupertinoIcons.person,
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryChip(String label, {bool isSelected = false}) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Padding(
      padding: const EdgeInsets.only(right: 8.0),
      child: PlatformHelper.shouldUseMaterial
          ? FilterChip(
              label: Text(
                label,
                style: TextStyle(
                  fontFamily: 'Roboto', // Pastikan font konsisten
                  fontSize: 14, // Ukuran font
                  decoration: TextDecoration.none,
                  color: isSelected
                      ? (isDarkMode ? Colors.white : Colors.white)
                      : (isDarkMode ? Colors.white70 : Colors.black),
                ),
              ),
              selected: isSelected,
              onSelected: (selected) {},
              backgroundColor: isDarkMode ? const Color(0xFF2C2C2C) : Colors.grey[200],
              selectedColor: AppTheme.primaryColor.withAlpha(isDarkMode ? 179 : 51),
              checkmarkColor: isDarkMode ? Colors.white : AppTheme.primaryColor,
            )
          : GestureDetector(
              onTap: () {},
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: isSelected
                      ? AppTheme.primaryColor.withAlpha(isDarkMode ? 179 : 51)
                      : (isDarkMode ? const Color(0xFF2C2C2C) : Colors.grey[200]),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Text(
                  label,
                  style: TextStyle(
                    fontFamily: 'Roboto', // Pastikan font konsisten
                    fontSize: 14, // Ukuran font
                    decoration: TextDecoration.none,
                    color: isSelected
                        ? AppTheme.primaryColor
                        : (isDarkMode ? Colors.white70 : Colors.black),
                    fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                  ),
                ),
              ),
            ),
    );
  }

  Widget _buildCategoryItem(String name, String imageUrl, int count) {
    return Container(
      width: 120,
      margin: const EdgeInsets.only(right: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withAlpha(51),
            spreadRadius: 1,
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Stack(
          children: [
            Positioned.fill(
              child: Image.network(
                imageUrl,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) {
                  return Container(
                    color: Colors.grey[300],
                    child: const Center(
                      child: Icon(Icons.image_not_supported, size: 30),
                    ),
                  );
                },
              ),
            ),
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      Colors.black.withAlpha(179),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              bottom: 10,
              left: 10,
              right: 10,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 14, // Ukuran font lebih kecil
                      decoration: TextDecoration.none, // Hilangkan underline
                    ),
                  ),
                  Text(
                    '$count resep',
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 12,
                      decoration: TextDecoration.none,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTipItem(String title, String description, String imageUrl) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
            child: Image.network(
              imageUrl,
              height: 150,
              width: double.infinity,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) {
                return Container(
                  height: 150,
                  color: Colors.grey[300],
                  child: const Center(
                    child: Icon(Icons.image_not_supported, size: 50),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  description,
                  style: TextStyle(
                    color: Theme.of(context).brightness == Brightness.dark
                        ? AppTheme.darkMutedTextColor
                        : Colors.grey[600],
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}