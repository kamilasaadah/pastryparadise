class Step {
  final String description;

  Step({
    required this.description,
  });
}

