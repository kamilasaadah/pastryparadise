import '../models/review.dart';

final List<Review> dummyReviews = [
  Review(
    id: 1,
    userName: 'Sarah Johnson',
    userImage: 'https://randomuser.me/api/portraits/women/12.jpg',
    rating: 5.0,
    comment: 'This recipe is amazing! The croissants turned out perfectly flaky and buttery. Will definitely make again.',
    date: '2 days ago',
  ),
  Review(
    id: 2,
    userName: 'Michael Chen',
    userImage: 'https://randomuser.me/api/portraits/men/22.jpg',
    rating: 4.5,
    comment: 'Great recipe, though I found it a bit time-consuming. The taste was worth it though!',
    date: '1 week ago',
  ),
  Review(
    id: 3,
    userName: 'Emily Rodriguez',
    userImage: 'https://randomuser.me/api/portraits/women/33.jpg',
    rating: 5.0,
    comment: 'Perfect instructions! My family loved these pastries and asked me to make them again.',
    date: '2 weeks ago',
  ),
  Review(
    id: 4,
    userName: 'David Wilson',
    userImage: 'https://randomuser.me/api/portraits/men/45.jpg',
    rating: 3.5,
    comment: 'Good recipe but I had some trouble with the folding technique. Flavor was still good though.',
    date: '3 weeks ago',
  ),
  Review(
    id: 5,
    userName: 'Jessica Taylor',
    userImage: 'https://randomuser.me/api/portraits/women/56.jpg',
    rating: 4.0,
    comment: 'Delicious! I added a bit more sugar to the dough and it turned out great.',
    date: '1 month ago',
  ),
];

